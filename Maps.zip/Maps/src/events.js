const EVENT_START = 'measure_start';
const EVENT_END = 'measure_end';
const EVENT_CHANGE = 'measure_change';

export { EVENT_START, EVENT_END, EVENT_CHANGE };
