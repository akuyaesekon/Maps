export const UnitTypeId = {
  METRIC: 'metric',
  IMPERIAL: 'imperial',
  NAUTICAL: 'nautical',
};
